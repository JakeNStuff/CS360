package com.example.JMP2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Registration extends AppCompatActivity {


    private EditText NewName;
    private EditText NewPass;
    private EditText CompanyID;
    private EditText ContactID;
    private Button Register2;
    private Button RegisterSMS;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        NewName = (EditText) findViewById(R.id.Username);
        NewPass = (EditText) findViewById(R.id.Password);
        CompanyID = (EditText) findViewById(R.id.COMPANYtext);
        ContactID = (EditText) findViewById(R.id.CONTACTtext);
        Register2 = (Button) findViewById(R.id.Registration);
        RegisterSMS = (Button) findViewById(R.id.SMSregistration);

        Register2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(NewName.getText().toString(), NewPass.getText().toString(), CompanyID.getText().toString(), ContactID.getText().toString());
            }
        });
        RegisterSMS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate(NewName.getText().toString(), NewPass.getText().toString(), CompanyID.getText().toString(), ContactID.getText().toString());
            }
        });
    }
 //Example Inc, Example, 12345 ###-###-#### are the example credentials.
    private void validate(String userName, String userPassword, String userCompany, String userContact) {
        if ((userName.equals("Example")) && (userPassword.equals("12345") && userCompany.equals("Example Inc") && userContact.equals("###-###-####"))) {
            Intent intent = new Intent(Registration.this, MainActivity.class);
            startActivity(intent);
        }

    }

}