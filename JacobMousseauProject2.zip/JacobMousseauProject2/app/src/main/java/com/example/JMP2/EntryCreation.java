package com.example.JMP2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import java.util.ArrayList;

public class EntryCreation extends AppCompatActivity {


    private ArrayList<String> data =new ArrayList<String>();
    private ArrayList<String> data1 =new ArrayList<String>();
    private ArrayList<String> data2 =new ArrayList<String>();
    private ArrayList<String> data3 =new ArrayList<String>();

    private TableLayout table;

    EditText Item,Stock,Note;
    Button AddEntry,Return;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_entry_creation);


        Item = (EditText)findViewById(R.id.Item);
        Stock = (EditText)findViewById(R.id.Stock);
        Note = (EditText)findViewById(R.id.Note);
        AddEntry = (Button)findViewById(R.id.AddEntry);
        Return = (Button)findViewById(R.id.Return);

        //Adds the entered information into the list of entries.
        //The entry shows up in the preview.
        AddEntry.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                add();
            }
        });
        //Returns you to the main inventory page, ideally, new information should be here.
        //Currently, Unable to get the information onto the main inventory activity
        Return.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(EntryCreation.this, Inventory.class);
                startActivity(intent);
            }

        });
    }
    //Information needed to add the new information to the table.
    public void add() {

    String ItemName = Item.getText().toString();
    String StockAmt = Stock.getText().toString();
    String Notation = Note.getText().toString();

    data.add(ItemName);
    data1.add(StockAmt);
    data2.add(Notation);

    TableLayout table = (TableLayout)findViewById(R.id.InventoryTable);
    TableRow row = new TableRow(this);
    TextView t1= new TextView(this);
    TextView t2= new TextView(this);
    TextView t3= new TextView(this);

    for(int i = 0; i< data.size(); i ++)
    {
        String iname = data.get(i);
        String istock = data1.get(i);
        String inote = data2.get(i);

        t1.setText(iname);
        t2.setText(istock);
        t3.setText(inote);
    }
    row.addView(t1);
    row.addView(t2);
    row.addView(t3);
    table.addView(row);

    Item.setText("");
    Stock.setText("");
    Note.setText("");
    }


}